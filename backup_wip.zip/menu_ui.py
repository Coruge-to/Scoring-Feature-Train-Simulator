from PyQt6.QtCore import Qt
from PyQt6.QtGui import QColor, QFontMetrics, QPen
from config import *
from utils import draw_text_with_outline

def draw_menu(self, painter, logical_width):
    # ==========================================================
    # ★★★ UI青枠 微調整用パラメータ ★★★
    # ==========================================================
    GLOBAL_BOX_X_OFFSET = -3
    MENU_BOX_Y_OFFSET = 1
    SCORING_BOX_Y_OFFSET = -4
    MAIN_ROW0_STA_MAX_W = 400
    # ==========================================================

    painter.setPen(Qt.PenStyle.NoPen)
    painter.setBrush(QColor(0, 0, 0, 220))
    painter.drawRect(0, 0, int(logical_width), int(BASE_SCREEN_H))
    
    painter.save()
    painter.resetTransform()
    scale_x = self.width() / BASE_SCREEN_W
    scale_y = self.height() / BASE_SCREEN_H
    menu_scale = min(scale_x, scale_y)
    offset_x = (self.width() - BASE_SCREEN_W * menu_scale) / 2
    offset_y = (self.height() - BASE_SCREEN_H * menu_scale) / 2
    painter.translate(offset_x, offset_y)
    painter.scale(menu_scale, menu_scale)
    
    MENU_OUTLINE = COLOR_OUTLINE_BLACK
    MENU_TEXT = COLOR_WHITE
    MENU_ERROR = COLOR_B_EMG
    HIGHLIGHT_COLOR = QColor(30, 80, 150, 200) 
    
    center_x = BASE_SCREEN_W / 2
    self.menu_click_zones.clear()

    def draw_menu_item(text, y, is_selected, action_idx, align="center", x_offset=0):
        fm = QFontMetrics(self.font_normal)
        text_w = fm.horizontalAdvance(text)
        
        if align == "center":
            draw_x = center_x
            box_x = center_x - (text_w / 2) - 30 + GLOBAL_BOX_X_OFFSET
        elif align == "left":
            draw_x = center_x + x_offset
            box_x = draw_x - 30 + GLOBAL_BOX_X_OFFSET
        elif align == "right":
            draw_x = center_x + x_offset
            box_x = draw_x - text_w - 30 + GLOBAL_BOX_X_OFFSET
        
        box_w = text_w + 60
        box_h = fm.height() + 16
        box_y = y - fm.ascent() - 6 - (fm.descent() // 2) + MENU_BOX_Y_OFFSET

        if is_selected:
            painter.setPen(Qt.PenStyle.NoPen)
            painter.setBrush(HIGHLIGHT_COLOR)
            painter.drawRoundedRect(int(box_x), int(box_y), int(box_w), int(box_h), 8, 8)

        draw_text_with_outline(painter, text, self.font_normal, MENU_TEXT, MENU_OUTLINE, draw_x, y, align, passes=8)
        
        if align == "center":
            self.menu_click_zones.append((center_x - 400, box_y, center_x + 400, box_y + box_h, action_idx))
        else:
            self.menu_click_zones.append((box_x, box_y, box_x + box_w, box_y + box_h, action_idx))

    def draw_setting_item(name, is_on, y, is_selected, action_idx):
        fm = QFontMetrics(self.font_normal)
        box_w = 800 
        box_x = center_x - (box_w / 2) + GLOBAL_BOX_X_OFFSET
        box_h = fm.height() + 16
        box_y = y - fm.ascent() - 6 - (fm.descent() // 2) + MENU_BOX_Y_OFFSET

        if is_selected:
            painter.setPen(Qt.PenStyle.NoPen)
            painter.setBrush(HIGHLIGHT_COLOR)
            painter.drawRoundedRect(int(box_x), int(box_y), int(box_w), int(box_h), 8, 8)

        draw_text_with_outline(painter, name, self.font_normal, MENU_TEXT, MENU_OUTLINE, box_x - GLOBAL_BOX_X_OFFSET + 40, y, "left", passes=8)
        val_text = "ON" if is_on else "OFF"
        val_color = COLOR_P if is_on else COLOR_B_EMG
        draw_text_with_outline(painter, val_text, self.font_normal, val_color, COLOR_WHITE, box_x - GLOBAL_BOX_X_OFFSET + box_w - 40, y, "right", passes=8)
        self.menu_click_zones.append((box_x, box_y, box_x + box_w, box_y + box_h, action_idx))

    title_text = ""
    title_y = 200
    if self.menu_state == 1: title_text = "=== メニュー ==="
    elif self.menu_state == 2: title_text = "=== 選択した駅からやり直す ==="
    elif self.menu_state == 4: title_text = "=== 環境設定 ==="
    elif self.menu_state in [5, 7]: 
        title_text = "=== 採点設定 (1/2) ==="
        title_y = 100
    elif self.menu_state == 6: 
        title_text = "=== 採点設定 (2/2) : 減点項目 ==="
        title_y = 100

    if title_text and self.menu_state != 3:
        draw_text_with_outline(painter, title_text, self.font_big, MENU_TEXT, MENU_OUTLINE, center_x, title_y, "center", passes=8)

    if self.menu_state != 3:
        if self.menu_state in [5, 6, 7]:
            draw_text_with_outline(painter, "↑ ↓ ← → : 選択  |  Enter / Click : 決定・リスト開閉", self.font_normal, COLOR_WHITE, COLOR_OUTLINE_BLACK, center_x, 980, "center", passes=8)
            draw_text_with_outline(painter, "Backspace : 戻る / 白紙入力(項目削除)  |  F6 : 閉じる", self.font_normal, COLOR_WHITE, COLOR_OUTLINE_BLACK, center_x, 1030, "center", passes=8)
        else:
            draw_text_with_outline(painter, "↑ ↓ : 選択  |  Enter / Click : 決定・切替", self.font_normal, COLOR_WHITE, COLOR_OUTLINE_BLACK, center_x, 980, "center", passes=8)
            draw_text_with_outline(painter, "Backspace : 戻る  |  F6 : 閉じる", self.font_normal, COLOR_WHITE, COLOR_OUTLINE_BLACK, center_x, 1030, "center", passes=8)

    def get_sta_name(idx):
        if not self.station_list: return "データ未受信"
        if idx == -1:
            for i in range(len(self.station_list)-1, -1, -1):
                if self.station_list[i].get("is_timing", False):
                    return self.station_list[i]["name"]
            return "不明"
        if 0 <= idx < len(self.station_list):
            return self.station_list[idx]["name"]
        return "不明"

    if self.menu_state == 1:
        items = self.menu_items_on if self.is_scoring_mode else self.menu_items_off
        for i, text in enumerate(items):
            draw_menu_item(text, 350 + i * 80, (i == self.menu_cursor), i, "center")

    elif self.menu_state == 2:
        pass # main.py側で描画

    elif self.menu_state == 3:
        pass # main.py側で描画

    elif self.menu_state == 4:
        for i in range(7):
            key = self.settings_keys[i]
            name = self.settings_names[i]
            is_on = self.disp_settings[key]
            fm = QFontMetrics(self.font_normal)
            box_w, box_x = 800, center_x - 400 + GLOBAL_BOX_X_OFFSET
            box_y = 300 + i * 70 - fm.ascent() - 6 - (fm.descent() // 2) + MENU_BOX_Y_OFFSET
            if i == self.menu_cursor:
                painter.setPen(Qt.PenStyle.NoPen)
                painter.setBrush(HIGHLIGHT_COLOR)
                painter.drawRoundedRect(int(box_x), int(box_y), int(box_w), int(fm.height() + 16), 8, 8)
            draw_text_with_outline(painter, name, self.font_normal, MENU_TEXT, MENU_OUTLINE, box_x - GLOBAL_BOX_X_OFFSET + 40, 300 + i * 70, "left", passes=8)
            draw_text_with_outline(painter, "ON" if is_on else "OFF", self.font_normal, COLOR_P if is_on else COLOR_B_EMG, COLOR_WHITE, box_x - GLOBAL_BOX_X_OFFSET + box_w - 40, 300 + i * 70, "right", passes=8)

    elif self.menu_state in [5, 7]:
        sta_start = get_sta_name(self.setting_start_idx)
        sta_end = get_sta_name(self.setting_end_idx)

        # =========================================================
        # ★ メイン設定画面 (1/2) のレイアウト微調整パラメータ
        # =========================================================
        MAIN_X_OFFSET = 50   # ★ 全体を右にズラす量 (0だと今まで通り。間隔は変えずに全体が動く)
        list_y_start  = 200
        row_h         = 65
        label_x       = 100 + MAIN_X_OFFSET      
        val_x_start   = 550 + MAIN_X_OFFSET  
        # =========================================================
        
        fm = QFontMetrics(self.font_menu)

        def draw_label(row_idx, text, y, text_color, outline_color):
            vis_rules = min(3, len(self.brake_rules))
            if self.menu_state == 5 and (self.menu_cursor == row_idx or (row_idx == 4 and 4 <= self.menu_cursor < 4 + vis_rules)):
                if self.menu_cursor_x == -1:
                    painter.setPen(Qt.PenStyle.NoPen)
                    painter.setBrush(HIGHLIGHT_COLOR)
                    label_w = fm.horizontalAdvance(text)
                    painter.drawRoundedRect(int(label_x - 15 + GLOBAL_BOX_X_OFFSET), int(y - fm.ascent() - 6 + SCORING_BOX_Y_OFFSET), int(label_w + 30), int(fm.height() + 12), 6, 6)
            draw_text_with_outline(painter, text, self.font_menu, text_color, outline_color, label_x, y, "left", passes=8)

        def draw_blocks(row_idx, blocks, y, is_sub_window=False):
            cx = val_x_start if not is_sub_window else 150 
            interactive_idx = 0
            for b in blocks:
                text = str(b["text"])
                is_interactive = b.get("interactive", False)
                t_color = b.get("color", COLOR_WHITE)
                o_color = b.get("outline", COLOR_OUTLINE_BLACK)
                max_w = b.get("max_w", None)
                
                text_w = fm.horizontalAdvance(text)
                
                is_scaled = False
                sr = 1.0
                if max_w and text_w > max_w:
                    is_scaled = True
                    sr = max_w / text_w
                    actual_box_w = max_w
                else:
                    actual_box_w = text_w

                if is_interactive:
                    if not is_sub_window:
                        is_focused = (self.menu_state == 5 and self.menu_cursor == row_idx and self.menu_cursor_x == interactive_idx and not self.dropdown_active)
                    else:
                        is_focused = (self.menu_state == 7 and self.sub_cursor == row_idx and self.sub_cursor_x == interactive_idx and not self.dropdown_active)
                        
                    if is_focused:
                        painter.setPen(Qt.PenStyle.NoPen)
                        if self.menu_state == 5 and row_idx == 1 and self.input_mode_active:
                            painter.setBrush(QColor(150, 50, 50, 200)) 
                        else:
                            painter.setBrush(HIGHLIGHT_COLOR)
                        box_y = y - fm.ascent() - 6 + SCORING_BOX_Y_OFFSET
                        painter.drawRoundedRect(int(cx - 10 + GLOBAL_BOX_X_OFFSET), int(box_y), int(actual_box_w + 20), int(fm.height() + 12), 6, 6)
                    interactive_idx += 1

                if is_scaled:
                    cy = y - fm.ascent() + fm.height() / 2.0
                    painter.save()
                    painter.translate(cx, cy)
                    painter.scale(sr, sr)
                    painter.translate(0, -cy + y)
                    draw_text_with_outline(painter, text, self.font_menu, t_color, o_color, 0, 0, "left", passes=8)
                    painter.restore()
                else:
                    draw_text_with_outline(painter, text, self.font_menu, t_color, o_color, cx, y, "left", passes=8)
                
                cx += actual_box_w + 20

        draw_label(0, "採点区間", list_y_start, COLOR_WHITE, COLOR_OUTLINE_BLACK)
        draw_blocks(0, [
            {"text": sta_start, "interactive": True, "max_w": MAIN_ROW0_STA_MAX_W},
            {"text": "～", "interactive": False},
            {"text": sta_end, "interactive": True, "max_w": MAIN_ROW0_STA_MAX_W}
        ], list_y_start)

        tl = int(self.bve_train_length)
        draw_label(1, "停車駅採点範囲", list_y_start + row_h, COLOR_WHITE, COLOR_OUTLINE_BLACK)
        margin_disp = self.input_buffer if self.input_mode_active else str(self.setting_stop_distance)
        if not margin_disp: margin_disp = "_" 
        draw_blocks(1, [
            {"text": margin_disp, "interactive": True},
            {"text": "m", "interactive": False}
        ], list_y_start + row_h)

        draw_label(2, "運転時分", list_y_start + row_h*2, COLOR_N, COLOR_WHITE)
        change_x_time = label_x + fm.horizontalAdvance("運転時分　")
        is_focused_time = (self.menu_state == 5 and self.menu_cursor == 2 and self.menu_cursor_x == 0 and not self.dropdown_active)
        if is_focused_time:
            painter.setPen(Qt.PenStyle.NoPen)
            painter.setBrush(HIGHLIGHT_COLOR)
            painter.drawRoundedRect(int(change_x_time - 10 + GLOBAL_BOX_X_OFFSET), int(list_y_start + row_h*2 - fm.ascent() - 6 + SCORING_BOX_Y_OFFSET), int(fm.horizontalAdvance("変更") + 20), int(fm.height() + 12), 6, 6)
        draw_text_with_outline(painter, "変更", self.font_menu, COLOR_WHITE, COLOR_OUTLINE_BLACK, change_x_time, list_y_start + row_h*2, "left", passes=8)
        
        draw_blocks(2, [{"text": "ON", "interactive": False, "color": COLOR_P, "outline": COLOR_WHITE}], list_y_start + row_h*2)

        draw_label(3, "停止位置", list_y_start + row_h*3, COLOR_N, COLOR_WHITE)
        draw_blocks(3, [{"text": "ON", "interactive": False, "color": COLOR_P, "outline": COLOR_WHITE}], list_y_start + row_h*3)

        draw_label(4, "基本制動", list_y_start + row_h*4, COLOR_N, COLOR_WHITE)
        
        change_x = label_x + fm.horizontalAdvance("基本制動　") 
        change_text = "変更"
        text_w = fm.horizontalAdvance(change_text)
        is_focused = (self.menu_state == 5 and self.menu_cursor == 4 and self.menu_cursor_x == 0 and not self.dropdown_active)
        if is_focused:
            painter.setPen(Qt.PenStyle.NoPen)
            painter.setBrush(HIGHLIGHT_COLOR)
            painter.drawRoundedRect(int(change_x - 10 + GLOBAL_BOX_X_OFFSET), int(list_y_start + row_h*4 - fm.ascent() - 6 + SCORING_BOX_Y_OFFSET), int(text_w + 20), int(fm.height() + 12), 6, 6)
        draw_text_with_outline(painter, change_text, self.font_menu, COLOR_WHITE, COLOR_OUTLINE_BLACK, change_x, list_y_start + row_h*4, "left", passes=8)


        vis_rules = min(3, len(self.brake_rules))
        FIXED_STA_W = 280      
        
        box_y_offset = 12
        box_width = 1210
        box_height = row_h * vis_rules + 5
        
        is_summary_focused = (self.menu_state == 5 and self.menu_cursor == 4 and self.menu_cursor_x == 1 and not self.dropdown_active)
        if is_summary_focused:
            painter.setPen(Qt.PenStyle.NoPen)
            painter.setBrush(QColor(30, 80, 150, 150))
            painter.drawRoundedRect(int(val_x_start - 20 + GLOBAL_BOX_X_OFFSET), int(list_y_start + row_h*4 - fm.ascent() - box_y_offset), box_width, int(box_height), 6, 6)

        col_summary_x = val_x_start + FIXED_STA_W + 15 + (fm.horizontalAdvance("～") // 2)

        if self.summary_scroll > 0:
            draw_text_with_outline(painter, "▲", self.font_normal, COLOR_WHITE, COLOR_OUTLINE_BLACK, col_summary_x, list_y_start + row_h*4 - 68, "center", passes=8)
            
        for i in range(vis_rules):
            r_idx = self.summary_scroll + i
            if r_idx >= len(self.brake_rules): break
            r_y = list_y_start + row_h * (4 + i) 
            rule = self.brake_rules[r_idx]
            r_start = get_sta_name(self.setting_start_idx) if r_idx == 0 else get_sta_name(self.brake_rules[r_idx-1]["end_idx"])
            r_end = get_sta_name(self.setting_end_idx) if rule["end_idx"] == -1 else get_sta_name(rule["end_idx"])
            
            cx = val_x_start
            
            w_start = fm.horizontalAdvance(r_start)
            if w_start > FIXED_STA_W:
                sr = FIXED_STA_W / w_start
                cy = r_y - fm.ascent() + fm.height() / 2.0
                painter.save()
                painter.translate(cx, cy)
                painter.scale(sr, sr)
                painter.translate(0, -cy + r_y)
                draw_text_with_outline(painter, r_start, self.font_menu, COLOR_WHITE, COLOR_OUTLINE_BLACK, 0, 0, "left", passes=8)
                painter.restore()
            else:
                draw_text_with_outline(painter, r_start, self.font_menu, COLOR_WHITE, COLOR_OUTLINE_BLACK, cx, r_y, "left", passes=8)
            cx += FIXED_STA_W + 15
            
            draw_text_with_outline(painter, "～", self.font_menu, COLOR_WHITE, COLOR_OUTLINE_BLACK, cx, r_y, "left", passes=8)
            cx += fm.horizontalAdvance("～") + 15
            
            w_end = fm.horizontalAdvance(r_end)
            if w_end > FIXED_STA_W:
                sr = FIXED_STA_W / w_end
                cy = r_y - fm.ascent() + fm.height() / 2.0
                painter.save()
                painter.translate(cx, cy)
                painter.scale(sr, sr)
                painter.translate(0, -cy + r_y)
                draw_text_with_outline(painter, r_end, self.font_menu, COLOR_WHITE, COLOR_OUTLINE_BLACK, 0, 0, "left", passes=8)
                painter.restore()
            else:
                draw_text_with_outline(painter, r_end, self.font_menu, COLOR_WHITE, COLOR_OUTLINE_BLACK, cx, r_y, "left", passes=8)
            cx += FIXED_STA_W + 15
            
            draw_text_with_outline(painter, ":", self.font_menu, COLOR_WHITE, COLOR_OUTLINE_BLACK, cx, r_y, "left", passes=8)
            cx += fm.horizontalAdvance(":") + 20
            
            if rule["apply"] == "OFF":
                draw_text_with_outline(painter, "OFF", self.font_menu, COLOR_B_EMG, COLOR_WHITE, cx, r_y, "left", passes=8)
            else:
                draw_text_with_outline(painter, rule["apply"], self.font_menu, COLOR_WHITE, COLOR_OUTLINE_BLACK, cx, r_y, "left", passes=8)
                cx += fm.horizontalAdvance(rule["apply"]) + 15
                draw_text_with_outline(painter, "制動 /", self.font_menu, COLOR_WHITE, COLOR_OUTLINE_BLACK, cx, r_y, "left", passes=8)
                cx += fm.horizontalAdvance("制動 /") + 15
                draw_text_with_outline(painter, rule["release"], self.font_menu, COLOR_WHITE, COLOR_OUTLINE_BLACK, cx, r_y, "left", passes=8)
                cx += fm.horizontalAdvance(rule["release"]) + 15
                draw_text_with_outline(painter, "緩め", self.font_menu, COLOR_WHITE, COLOR_OUTLINE_BLACK, cx, r_y, "left", passes=8)

        if self.summary_scroll + 3 < len(self.brake_rules):
            draw_text_with_outline(painter, "▼", self.font_normal, COLOR_WHITE, COLOR_OUTLINE_BLACK, col_summary_x, list_y_start + row_h*(4 + vis_rules), "center", passes=8)

        last_row = 5
        btn_y = 720 
        draw_menu_item("次へ (減点項目の設定)", btn_y, (self.menu_state == 5 and self.menu_cursor == last_row and self.menu_cursor_x == -1), last_row, "center")

        desc_y = 770 
        desc_h = 135 
        painter.setPen(QPen(QColor(150, 150, 150), 2))
        painter.setBrush(QColor(20, 20, 20, 220))
        painter.drawRoundedRect(150, int(desc_y), 1620, int(desc_h), 10, 10)

        actual_margin = self.setting_stop_distance

        desc_dict = {
            0: "【 採点区間 】\n採点を行う区間を設定します。\n（※デフォルト:始発駅～終着駅）",
            1: f"【 停車駅採点範囲 】\n停車駅において、採点を行う停止位置からの距離を設定します。キーボードで数値入力が可能です。\n列車長より短い値は入力できません。（※列車長 {tl} m ＋ マージン {max(0, actual_margin - tl)} m ＝ 判定距離 {actual_margin} m）",
            2: "【 運転時分 】\n指定された採時駅への到着・出発時刻の正確さを採点します。\n（※0～±9秒 : 300点、±10～±19秒 : 200点、±20秒～±29秒 : 100点、±30秒～ : 0点）",
            3: "【 停止位置 】\n停車駅での停止位置の正確さを採点します。誤差0.00 mに近いほど高得点になります。\n （※許容範囲に停車した時、停止位置x[m]とすると、点数y = 500 × (1 - x)）",
            4: "【 基本制動 】\n駅に停車する際、指定された回数で制動・緩め操作が行われたかを採点します。\n（※基本制動の条件を満たすと500点、さらに0.00 mに停車した場合はボーナス500点）",
            last_row: "次の設定ページ（減点項目の設定）へ進みます。"
        }
        
        desc_text = ""
        if self.menu_state == 5:
            if self.menu_cursor == 2 and self.menu_cursor_x == 0:
                desc_text = "【 運転時分 設定 】\n駅ごとの採時 / 非採時の設定を個別に変更します。\n（※採点開始駅は非採時で固定されます）"
            elif self.menu_cursor == 4 and self.menu_cursor_x == 0:
                desc_text = "【 基本制動 設定 】\n特定区間だけ異なる基本制動ルールを適用したい場合に追加・編集します。\nルールはチェーン（数珠繋ぎ）になります。"
            else:
                desc_text = desc_dict.get(self.menu_cursor, "")

        for j, line in enumerate(desc_text.split('\n')):
            draw_text_with_outline(painter, line, self.font_desc, COLOR_WHITE, COLOR_OUTLINE_BLACK, 180, desc_y + 40 + (j * 40), "left", passes=8)

        if self.menu_state == 7:
            painter.setPen(Qt.PenStyle.NoPen)
            painter.setBrush(QColor(0,0,0, 180))
            painter.drawRect(0,0, int(BASE_SCREEN_W), int(BASE_SCREEN_H))
            
            sub_w, sub_h = 1700, 850
            sub_x, sub_y = 110, (BASE_SCREEN_H - sub_h) / 2
            
            painter.setBrush(QColor(30, 30, 30, 240))
            painter.setPen(QPen(QColor(150, 150, 150), 3))
            painter.drawRoundedRect(int(sub_x), int(sub_y), int(sub_w), int(sub_h), 12, 12)
            
            draw_text_with_outline(painter, "=== 基本制動 設定 ===", self.font_big, COLOR_WHITE, COLOR_OUTLINE_BLACK, center_x, sub_y + 130, "center", passes=8)
            
            vis_rules = min(5, len(self.brake_rules)) 
            
            # =========================================================
            # ★ 基本制動設定UI 微調整パラメータ
            # =========================================================
            sub_val_x_start = 300  # ★ 左端の開始X座標 (鶴さん指定の300)
            SUB_FIXED_STA_W = 350  # 駅名の固定幅
            gap_tilde = 15         
            gap_sta2 = 15          
            gap_colon = 15         
            gap_rule = 20          
            # =========================================================
            
            colon_x = sub_val_x_start + SUB_FIXED_STA_W + gap_tilde + fm.horizontalAdvance("～") + gap_sta2 + SUB_FIXED_STA_W + gap_colon
            sub_col_summary_x = colon_x + (fm.horizontalAdvance(":") // 2)

            if self.sub_scroll > 0:
                draw_text_with_outline(painter, "▲", self.font_normal, COLOR_WHITE, COLOR_OUTLINE_BLACK, sub_col_summary_x, sub_y + 200, "center", passes=8)
            
            sub_list_y_start = sub_y + 275 
            
            for i in range(vis_rules):
                r_idx = self.sub_scroll + i
                if r_idx >= len(self.brake_rules): break
                rule = self.brake_rules[r_idx]
                r_start = sta_start if r_idx == 0 else get_sta_name(self.brake_rules[r_idx-1]["end_idx"])
                r_end = sta_end if rule["end_idx"] == -1 else get_sta_name(rule["end_idx"])
                is_last = (r_idx == len(self.brake_rules) - 1)
                r_y = sub_list_y_start + (i * 70) 
                
                cx = sub_val_x_start 
                
                w_start = fm.horizontalAdvance(r_start)
                if w_start > SUB_FIXED_STA_W:
                    sr = SUB_FIXED_STA_W / w_start
                    cy = r_y - fm.ascent() + fm.height() / 2.0
                    painter.save()
                    painter.translate(cx, cy)
                    painter.scale(sr, sr)
                    painter.translate(0, -cy + r_y)
                    draw_text_with_outline(painter, r_start, self.font_menu, COLOR_WHITE, COLOR_OUTLINE_BLACK, 0, 0, "left", passes=8)
                    painter.restore()
                else:
                    draw_text_with_outline(painter, r_start, self.font_menu, COLOR_WHITE, COLOR_OUTLINE_BLACK, cx, r_y, "left", passes=8)
                cx += SUB_FIXED_STA_W + gap_tilde
                
                draw_text_with_outline(painter, "～", self.font_menu, COLOR_WHITE, COLOR_OUTLINE_BLACK, cx, r_y, "left", passes=8)
                cx += fm.horizontalAdvance("～") + gap_sta2
                
                w_end = fm.horizontalAdvance(r_end)
                is_focused = (self.sub_cursor == r_idx and self.sub_cursor_x == 0 and not self.dropdown_active)
                
                if w_end > SUB_FIXED_STA_W:
                    if is_focused and is_last:
                        painter.setPen(Qt.PenStyle.NoPen)
                        painter.setBrush(HIGHLIGHT_COLOR)
                        painter.drawRoundedRect(int(cx - 10 + GLOBAL_BOX_X_OFFSET), int(r_y - fm.ascent() - 6 + SCORING_BOX_Y_OFFSET), int(SUB_FIXED_STA_W + 20), int(fm.height() + 12), 6, 6)
                        
                    sr = SUB_FIXED_STA_W / w_end
                    cy = r_y - fm.ascent() + fm.height() / 2.0
                    painter.save()
                    painter.translate(cx, cy)
                    painter.scale(sr, sr)
                    painter.translate(0, -cy + r_y)
                    draw_text_with_outline(painter, r_end, self.font_menu, COLOR_WHITE, COLOR_OUTLINE_BLACK, 0, 0, "left", passes=8)
                    painter.restore()
                else:
                    if is_focused and is_last:
                        painter.setPen(Qt.PenStyle.NoPen)
                        painter.setBrush(HIGHLIGHT_COLOR)
                        painter.drawRoundedRect(int(cx - 10 + GLOBAL_BOX_X_OFFSET), int(r_y - fm.ascent() - 6 + SCORING_BOX_Y_OFFSET), int(w_end + 20), int(fm.height() + 12), 6, 6)
                    draw_text_with_outline(painter, r_end, self.font_menu, COLOR_WHITE, COLOR_OUTLINE_BLACK, cx, r_y, "left", passes=8)
                cx += SUB_FIXED_STA_W + gap_colon
                
                draw_text_with_outline(painter, ":", self.font_menu, COLOR_WHITE, COLOR_OUTLINE_BLACK, cx, r_y, "left", passes=8)
                cx += fm.horizontalAdvance(":") + gap_rule
                
                idx_apply = 1 if is_last else 0
                idx_release = 2 if is_last else 1

                if rule["apply"] == "OFF":
                    tw = fm.horizontalAdvance("OFF")
                    if self.sub_cursor == r_idx and self.sub_cursor_x == idx_apply and not self.dropdown_active:
                        painter.setPen(Qt.PenStyle.NoPen)
                        painter.setBrush(HIGHLIGHT_COLOR)
                        painter.drawRoundedRect(int(cx - 10 + GLOBAL_BOX_X_OFFSET), int(r_y - fm.ascent() - 6 + SCORING_BOX_Y_OFFSET), int(tw + 20), int(fm.height() + 12), 6, 6)
                    draw_text_with_outline(painter, "OFF", self.font_menu, COLOR_B_EMG, COLOR_WHITE, cx, r_y, "left", passes=8)
                else:
                    tw = fm.horizontalAdvance(rule["apply"])
                    if self.sub_cursor == r_idx and self.sub_cursor_x == idx_apply and not self.dropdown_active:
                        painter.setPen(Qt.PenStyle.NoPen)
                        painter.setBrush(HIGHLIGHT_COLOR)
                        painter.drawRoundedRect(int(cx - 10 + GLOBAL_BOX_X_OFFSET), int(r_y - fm.ascent() - 6 + SCORING_BOX_Y_OFFSET), int(tw + 20), int(fm.height() + 12), 6, 6)
                    draw_text_with_outline(painter, rule["apply"], self.font_menu, COLOR_WHITE, COLOR_OUTLINE_BLACK, cx, r_y, "left", passes=8)
                    cx += tw + 15
                    
                    draw_text_with_outline(painter, "制動 /", self.font_menu, COLOR_WHITE, COLOR_OUTLINE_BLACK, cx, r_y, "left", passes=8)
                    cx += fm.horizontalAdvance("制動 /") + 15
                    
                    tw_rel = fm.horizontalAdvance(rule["release"])
                    if self.sub_cursor == r_idx and self.sub_cursor_x == idx_release and not self.dropdown_active:
                        painter.setPen(Qt.PenStyle.NoPen)
                        painter.setBrush(HIGHLIGHT_COLOR)
                        painter.drawRoundedRect(int(cx - 10 + GLOBAL_BOX_X_OFFSET), int(r_y - fm.ascent() - 6 + SCORING_BOX_Y_OFFSET), int(tw_rel + 20), int(fm.height() + 12), 6, 6)
                    draw_text_with_outline(painter, rule["release"], self.font_menu, COLOR_WHITE, COLOR_OUTLINE_BLACK, cx, r_y, "left", passes=8)
                    cx += tw_rel + 15
                    
                    draw_text_with_outline(painter, "緩め", self.font_menu, COLOR_WHITE, COLOR_OUTLINE_BLACK, cx, r_y, "left", passes=8)
            
            if self.sub_scroll + 5 < len(self.brake_rules):
                draw_text_with_outline(painter, "▼", self.font_normal, COLOR_WHITE, COLOR_OUTLINE_BLACK, sub_col_summary_x, sub_list_y_start + (5 * 70) + 10, "center", passes=8)
            
            row_undo = len(self.brake_rules) if len(self.brake_rules) > 1 else -1
            row_done = len(self.brake_rules) + 1 if len(self.brake_rules) > 1 else len(self.brake_rules)
            
            btn_base_y = sub_list_y_start + (5 * 70) + 90 
            if row_undo != -1:
                draw_menu_item("１つ前の設定を修正する (この行を削除)", btn_base_y, (self.sub_cursor == row_undo), row_undo, "center")
            draw_menu_item("設定完了", btn_base_y + 80, (self.sub_cursor == row_done), row_done, "center")

    elif self.menu_state == 6:
        draw_text_with_outline(painter, "=== 採点設定 (2/2) : 減点項目 ===", self.font_big, MENU_TEXT, MENU_OUTLINE, center_x, 200, "center", passes=8)
        draw_text_with_outline(painter, "※減点項目の個別設定は現在開発中です", self.font_normal, COLOR_WHITE, COLOR_OUTLINE_BLACK, center_x, 300, "center", passes=8)
        
        draw_menu_item("【デバッグ】全減点項目をONにして採点を開始する", 500, (self.menu_cursor == 0), 0, "center")
        draw_menu_item("ページ1に戻る", 600, (self.menu_cursor == 1), 1, "center")

    if self.dropdown_active and len(self.dropdown_options) > 0:
        fm = QFontMetrics(self.font_menu)
        max_w = max([fm.horizontalAdvance(opt["name"]) for opt in self.dropdown_options]) + 60
        box_w = max(250, max_w) 
        
        visible_opts = self.dropdown_options[self.dropdown_scroll : self.dropdown_scroll + 7]
        row_h = fm.height() + 16
        box_h = row_h * len(visible_opts) + 20
        
        start_x = center_x - (box_w / 2)
        start_y = BASE_SCREEN_H / 2 - (box_h / 2)
        
        painter.setPen(QPen(QColor(100, 100, 100), 4))
        painter.setBrush(QColor(20, 20, 20, 240))
        painter.drawRoundedRect(int(start_x), int(start_y), int(box_w), int(box_h), 8, 8)
        
        if self.dropdown_scroll > 0:
            draw_text_with_outline(painter, "▲", self.font_normal, COLOR_WHITE, COLOR_OUTLINE_BLACK, center_x, start_y - 10, "center", passes=8)
            
        for i, opt in enumerate(visible_opts):
            actual_idx = self.dropdown_scroll + i
            item_y = start_y + 10 + (i * row_h)
            if actual_idx == self.dropdown_cursor:
                painter.setPen(Qt.PenStyle.NoPen)
                painter.setBrush(HIGHLIGHT_COLOR)
                painter.drawRoundedRect(int(start_x + 5), int(item_y), int(box_w - 10), int(row_h), 4, 4)
                
            text_y_base = item_y + fm.ascent() + 8
            draw_text_with_outline(painter, opt["name"], self.font_menu, COLOR_WHITE, COLOR_OUTLINE_BLACK, center_x, text_y_base, "center", passes=8)
            
        if self.dropdown_scroll + 7 < len(self.dropdown_options):
            draw_text_with_outline(painter, "▼", self.font_normal, COLOR_WHITE, COLOR_OUTLINE_BLACK, center_x, start_y + box_h + 30, "center", passes=8)

    painter.restore()